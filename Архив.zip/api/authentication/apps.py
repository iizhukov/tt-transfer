from django.apps import AppConfig


class AuthenticationConfig(AppConfig):
    name = 'api.authentication'
    verbose_name: str = "Аутентификация"
