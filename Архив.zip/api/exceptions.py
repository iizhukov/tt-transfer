class TariffNotSpecifiedException(Exception):
    pass


class CalculatorException(Exception):
    pass


class RouteException(CalculatorException):
    pass
