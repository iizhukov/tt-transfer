class TariffNotSpecifiedException(Exception):
    pass
