from django.apps import AppConfig


class ActivityFeedConfig(AppConfig):
    name = 'api.activityFeed'
    verbose_name = "Лента Новостей"
