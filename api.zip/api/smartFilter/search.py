class TariffSearch:
    pass
