from django.apps import AppConfig


class SmartfilterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api.smartFilter'
